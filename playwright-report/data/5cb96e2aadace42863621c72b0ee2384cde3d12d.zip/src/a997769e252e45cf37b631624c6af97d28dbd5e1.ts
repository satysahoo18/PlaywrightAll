import { Locator, Page } from "@playwright/test";

export class OrangeHRMDashboardPage {
  readonly heading: Locator;

  constructor(private readonly page: Page) {
    this.heading = page.getByRole("heading", { name: "Dashboard" });
  }

  async isAtDashboard(): Promise<boolean> {
    await this.heading.waitFor({ state: "visible" });
    return new URL(this.page.url()).pathname.endsWith("/dashboard/index");
  }
}
